// ncurses ref: https://www.sbarjatiya.com/notes_wiki/index.php/Using_ncurses_library_with_C
// https://jbwyatt.com/ncurses.html is much better tho

// using gcc, compile with -lncurses

#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <ncurses.h>
#include "http/http.h"
#include "xml/html.h"

// error codes:
/*
0: no error
1: malformed http response
2: HTTP version did not match
3: malformed http status
4: URL parse error
5: Failed to lookup host
6: Error while obtaining host IP
7: Temporary error in name resolution
*/

// gets called with int as error
typedef void (*errorHandler)(int);

char *downloadAndOpenPage(char *url) {
    
    struct http_response parsedResponse = http_makeHTTPRequest(url);
    
    if (parsedResponse.error) {
        if (parsedResponse.error == 4) {
            return HTTP_makeStrCpy("Please enter a valid URL.\n");
        } else if (parsedResponse.error < 4) {
            return HTTP_makeStrCpy("Malformed HTTP response.\n");
        } else if (parsedResponse.error == 5) {
            return HTTP_makeStrCpy("Host not found.\n");
        } else if (parsedResponse.error == 6) {
            return HTTP_makeStrCpy("...");
        } else if (parsedResponse.error == 7) {
            return HTTP_makeStrCpy("Temporary error in name resolution.\n");
        } else if (parsedResponse.error == 101) {
            return HTTP_makeStrCpy("Network unreachable.\n");
        } else if (parsedResponse.error == 111) {
            return HTTP_makeStrCpy("Connection refused.\n");
        } else if (parsedResponse.error == 113) {
            return HTTP_makeStrCpy("No route to host.\n");
        } else {
            return HTTP_makeStrCpy("Error while connecting to host or receiving data from host.\n");
        }
    }
    
    // todo: handle headers
    return parsedResponse.response_body.data;/*
    printf("response details:\n");
    printf("    code: %d\n", parsedResponse.response_code);
    printf("    desc: %s\n", parsedResponse.response_description);
    printf("    chunked: %d\n", parsedResponse.is_chunked);
    printf("    content length: %d\n", parsedResponse.content_length);
    for (int i = 0; i < parsedResponse.num_headers; i ++) {
        printf("    header name: %s; header value: %s\n", parsedResponse.headers[i].name, parsedResponse.headers[i].value);
    }*/
}

// gets called with current state pointer and pressed button's descriptor
typedef void (*clickHandler)(void *, char *);

enum nc_page {
    PAGE_DOCUMENT_LOADED,
    PAGE_GOTO_DIALOG,
    PAGE_EMPTY,
};

char *nc_strcpy(const char *text) {
    char *newText = (char *) calloc(strlen(text) + 1, sizeof(char));
    strcpy(newText, text);
    return newText;
}


struct nc_text_area {
    int y;
    int x;
    int width;
    int height;
    int visible;
    char *currentText;
    char *descriptor;
    int selected;
};

struct nc_button {
    int y;
    int x;
    int visible;
    char *text;
    clickHandler onclick;
    char *descriptor;
    int selected;
};

struct nc_text {
    int y;
    int x;
    int visible;
    char *text;
    char *descriptor;
};

struct nc_selected {
    struct nc_text_area *textarea;
    struct nc_button *button;
};

struct nc_selected selectableFromButton(struct nc_button *button) {
    struct nc_selected select;
    select.button = button;
    select.textarea = NULL;
    return select;
}

struct nc_selected selectableFromTextarea(struct nc_text_area *textarea) {
    struct nc_selected select;
    select.button = NULL;
    select.textarea = textarea;
    return select;
}

struct nc_state {
    enum nc_page currentPage;
    struct xml_response currentLoadedDOM;
    
    struct nc_text_area text_areas[256];
    struct nc_button buttons[256];
    struct nc_text texts[256];
    int numTextAreas;
    int numButtons;
    int numTexts;
    
    struct nc_selected *selectables;
    int numSelectables;
    int selectableIndex;
    
    // todo: add a forward/back buffer
};

struct nc_text_area *getCurrentSelectedTextarea(struct nc_state *state) {
    for (int i = 0; i < state->numTextAreas; i ++) {
        if (state->text_areas[i].visible) {
            return &state->text_areas[i];
        }
    }
    return NULL;
}

struct nc_button *getCurrentSelectedButton(struct nc_state *state) {
    for (int i = 0; i < state->numButtons; i ++) {
        if (state->buttons[i].visible) {
            return &state->buttons[i];
        }
    }
    return NULL;
}

struct nc_button *getButtonByDescriptor(struct nc_state *state, char *descriptor) {
    int num = state->numButtons;
    for (int i = 0; i < num; i ++) {
        if (!strcmp(descriptor, state->buttons[i].descriptor)) {
            return &state->buttons[i];
        }
    }
    /*printf("Attempted to find a button that didn't exist!\n");
    exit(0);*/
    return NULL;
}

struct nc_text_area *getTextAreaByDescriptor(struct nc_state *state, char *descriptor) {
    int num = state->numTextAreas;
    for (int i = 0; i < num; i ++) {
        if (!strcmp(descriptor, state->text_areas[i].descriptor)) {
            return &state->text_areas[i];
        }
    }
    /*printf("Attempted to find a text area that didn't exist!\n");
    exit(0);*/
    return NULL;
}

struct nc_text *getTextByDescriptor(struct nc_state *state, char *descriptor) {
    int num = state->numTexts;
    for (int i = 0; i < num; i ++) {
        if (!strcmp(descriptor, state->texts[i].descriptor)) {
            return &state->texts[i];
        }
    }
    /*printf("Attempted to find a text that didn't exist!\n");
    exit(0);*/
    return NULL;
}

struct nc_button createNewButton(struct nc_state *state, int x, int y, char *text, clickHandler onclick, char *descriptor) {
    if (getButtonByDescriptor(state, descriptor) != NULL) {
        printf("Attempted to initialize a button with duplicate descriptor!\n");
        exit(0);
    }
    struct nc_button button;
    button.x = x;
    button.y = y;
    button.visible = 1;
    button.selected = 0;
    button.text = text;
    button.onclick = onclick;
    button.descriptor = nc_strcpy(descriptor);
    state->buttons[state->numButtons] = button;
    state->numButtons ++;
    
    state->selectables = (struct nc_selected *) realloc(state->selectables, (state->numSelectables + 1) * sizeof(struct nc_selected));
    state->selectables[state->numSelectables] = selectableFromButton(&state->buttons[state->numButtons - 1]);
    state->numSelectables ++;
    return button;
}

struct nc_text_area createNewTextarea(struct nc_state *state, int x, int y, int w, int h, char *descriptor) {
    if (getTextAreaByDescriptor(state, descriptor)) {
        printf("Attempted to initialize a text area with duplicate descriptor!\n");
        exit(0);
    }
    struct nc_text_area textarea;
    textarea.x = x;
    textarea.y = y;
    textarea.width = w;
    textarea.height = h;
    textarea.visible = 1;
    textarea.selected = 0;
    textarea.currentText = (char *) calloc(1024, sizeof(char));
    textarea.descriptor = nc_strcpy(descriptor);
    state->text_areas[state->numTextAreas] = textarea;
    state->numTextAreas ++;
    
    state->selectables = (struct nc_selected *) realloc(state->selectables, (state->numSelectables + 1) * sizeof(struct nc_selected));
    state->selectables[state->numSelectables] = selectableFromTextarea(&state->text_areas[state->numTextAreas - 1]);
    state->numSelectables ++;
    return textarea;
}

struct nc_text createNewText(struct nc_state *state, int x, int y, char *givenText, char *descriptor) {
    if (getButtonByDescriptor(state, descriptor)) {
        printf("Attempted to initialize a text area with duplicate descriptor!\n");
        exit(0);
    }
    struct nc_text text;
    text.x = x;
    text.y = y;
    text.visible = 1;
    text.text = nc_strcpy(givenText);
    text.descriptor = nc_strcpy(descriptor);
    state->texts[state->numTexts] = text;
    state->numTexts ++;
    return text;
}

char *getTextAreaRendered(struct nc_text_area textarea) {
    char *resultingText = (char *) calloc(textarea.width + 2, sizeof(char));

    int under = textarea.width - strlen(textarea.currentText);
    if (under < 0) under = 0;
    for (int i = 0; i < strlen(textarea.currentText); i ++) {
        resultingText[i] = textarea.currentText[i];
    }
    for (int i = 0; i < under; i ++) {
        resultingText[strlen(resultingText)] = '_';
    }

    return resultingText;
}

void ongotourl(void *state, char *_) {
    struct nc_state *realState = (struct nc_state *) state;
    // TODO
    realState->currentPage = PAGE_DOCUMENT_LOADED;
    getTextByDescriptor(realState, "gotoURL")->visible = 0;
    getTextAreaByDescriptor(realState, "urltextarea")->visible = 0;
    getButtonByDescriptor(realState, "gotobutton")->visible = 0;
    getTextByDescriptor(realState, "documentText")->visible = 1;
    
    char *data = downloadAndOpenPage(getTextAreaByDescriptor(realState, "urltextarea")->currentText);
    getTextByDescriptor(realState, "documentText")->text = data;
}

void initializeDisplayObjects(struct nc_state *state) {
    createNewText(state, 1, 1, "Go to a URL:", "gotoURL");
    createNewText(state, 0, 0, "Document is loading...", "documentText");
    createNewTextarea(state, 1, 3, 29, 1, "urltextarea");
    createNewButton(state, 1, 5, "OK", ongotourl, "gotobutton");
    getTextByDescriptor(state, "gotoURL")->visible = 0;
    getButtonByDescriptor(state, "gotobutton")->visible = 0;
    getTextAreaByDescriptor(state, "urltextarea")->visible = 0;
    getTextByDescriptor(state, "documentText")->visible = 0;
}

void initBrowserWindow(struct nc_state *state) {
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);
    //nodelay(stdscr, TRUE);
    initializeDisplayObjects(state);
    start_color();
    init_pair(1, COLOR_WHITE, COLOR_BLACK);
    init_pair(2, COLOR_BLACK, COLOR_WHITE);
}

void endProgram() {
    endwin();
    exit(0);
}

void openGotoPageDialog(struct nc_state *state) {
    struct nc_text_area *textarea = getTextAreaByDescriptor(state, "urltextarea");
    state->currentPage = PAGE_GOTO_DIALOG;
    getTextByDescriptor(state, "gotoURL")->visible = 1;
    textarea->visible = 1;
    getButtonByDescriptor(state, "gotobutton")->visible = 1;
    getTextByDescriptor(state, "documentText")->visible = 0;
    
    int curlen = strlen(textarea->currentText);
    while(curlen > 0) {
        curlen = strlen(textarea->currentText);
        textarea->currentText[curlen - 1] = '\0';
    }
}

void closeGotoPageDialog(struct nc_state *state) {
    state->currentPage = PAGE_EMPTY;
    getTextByDescriptor(state, "gotoURL")->visible = 0;
    getTextAreaByDescriptor(state, "urltextarea")->visible = 0;
    getButtonByDescriptor(state, "gotobutton")->visible = 0;
    
    struct nc_text_area *textarea = getTextAreaByDescriptor(state, "urltextarea");
}

void closeDocumentPage(struct nc_state *state) {
    state->currentPage = PAGE_EMPTY;
    getTextByDescriptor(state, "documentText")->visible = 0;
}

void closeCurrentWindow(struct nc_state *state) {
    switch(state->currentPage) {
        case PAGE_GOTO_DIALOG:
            closeGotoPageDialog(state);
            break;
        case PAGE_DOCUMENT_LOADED:
            closeDocumentPage(state);
            break;
        case PAGE_EMPTY:
            endProgram();
            break;
    }
}

void updateFocus_nc(struct nc_state *state) {
    int numTextAreas = state->numTextAreas;
    int numButtons = state->numButtons;
    for (int i = 0; i < numButtons; i ++) {
        state->buttons[i].selected = 0;
    }
    for (int i = 0; i < numTextAreas; i ++) {
        state->text_areas[i].selected = 0;
    }
    struct nc_selected curSelected = state->selectables[state->selectableIndex];
    if (curSelected.textarea == NULL) {
        struct nc_button *button = curSelected.button;
        button->selected = 1;
    } else if (curSelected.button == NULL) {
        struct nc_text_area *textarea = curSelected.textarea;
        //textarea.currentText[0] = 'Z';
        textarea->selected = 1;
    } else {
        // ...both are selected????????
    }
}

void render_nc(struct nc_state *browserState) {
    clear();
    int numTexts = browserState->numTexts;
    int numTextAreas = browserState->numTextAreas;
    int numButtons = browserState->numButtons;
    for (int i = 0; i < numTexts; i ++) {
        if (browserState->texts[i].visible) {
            mvprintw(browserState->texts[i].y, browserState->texts[i].x, browserState->texts[i].text);
        }
    }
    for (int i = 0; i < numButtons; i ++) {
        if (browserState->buttons[i].visible) {
            attron(COLOR_PAIR(1));
            if (browserState->buttons[i].selected) {
                attron(COLOR_PAIR(2));
            }
            mvprintw(
                browserState->buttons[i].y,
                browserState->buttons[i].x,
                browserState->buttons[i].text
            );
            attron(COLOR_PAIR(1));
            
            if (browserState->buttons[i].selected) {
                move(
                    browserState->buttons[i].y,
                    browserState->buttons[i].x
                );
            }
            curs_set(0);
        }
    }
    for (int i = 0; i < numTextAreas; i ++) {
        if (browserState->text_areas[i].visible) {
            attron(COLOR_PAIR(1));
            if (browserState->text_areas[i].selected) {
                attron(COLOR_PAIR(2));
            }
            mvprintw(
                browserState->text_areas[i].y,
                browserState->text_areas[i].x,
                getTextAreaRendered(browserState->text_areas[i])
            );
            attron(COLOR_PAIR(1));
            
            if (browserState->text_areas[i].selected) {
                move(
                    browserState->text_areas[i].y,
                    browserState->text_areas[i].x + strlen(browserState->text_areas[i].currentText)
                );
                curs_set(1);
            }
        }
    }
    // `refresh` is automatically called by getch, called after render_nc
}

void onKeyPress(struct nc_state *browserState, char ch) {
    int h, w;
    switch(ch) {
        case 15: // CTRL+O
            openGotoPageDialog(browserState);
            break;
        case '\t': // tab
            browserState->selectableIndex ++;
            if (browserState->selectableIndex >= browserState->numSelectables) {
                browserState->selectableIndex = 0;
            }
            break;
        case 24: // CTRL+X
            closeCurrentWindow(browserState);
            break;
    }
    struct nc_text_area *textarea = getCurrentSelectedTextarea(browserState);
    if (textarea != NULL) {
        int curlen = strlen(textarea->currentText);
        if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z') || (ch >= '0' && ch <= '9') || ch == '.' || ch == '/' || ch == ':' || ch == '#' || ch == '-') {
            if (curlen < textarea->width * textarea->height) {
                textarea->currentText[curlen] = ch;
            }
        } else if (ch == 7) {
            int curlen = strlen(textarea->currentText);
            if (curlen > 0) {
                textarea->currentText[curlen - 1] = '\0';
            }
        } else {/*
            textarea->currentText[0] = ch/10 + 48;
            textarea->currentText[1] = ch%10 + 48;//("ch: %d\n", ch);
            textarea->currentText[2] = 0;*/
        }
    }
    
    struct nc_button *button = getCurrentSelectedButton(browserState);
    if (button != NULL) {
        if (ch == 10) {
            button->onclick(browserState, button->descriptor);
        }
    }
}

void eventLoop(struct nc_state *browserState) {
    while (1) {
        char ch;
        updateFocus_nc(browserState);
        render_nc(browserState);
        if (ch = getch()) {
            onKeyPress(browserState, ch);
        }
        
        switch(browserState->currentPage) {
            case PAGE_DOCUMENT_LOADED:
                break;
        }
    }
}

/*
char *getTabsRepeated(int amount) {
    char *spaces = (char *) calloc(128 + (amount * 4), sizeof(char));
    for (int i = 0; i < amount * 4; i ++) {
        spaces[i] = ' ';
    }
    return spaces;
}

void recursiveDisplayXML(struct xml_list xml, int depth) {
    for (int i = 0; i < xml.count; i ++) {
        struct xml_node node = xml.nodes[i];
        if (node.type == NODE_DOCTYPE) {
            printf(strcat(getTabsRepeated(depth), "doctype node (#%d). contents: '%s'\n"), i, node.text_content);
        } else if (node.type == NODE_TEXT) {
            printf(strcat(getTabsRepeated(depth), "text node (#%d). contents: '%s'\n"), i, node.text_content);
            //printf(strcat(getTabsRepeated(depth), "text node (#%d). contents: '...'\n"), i);
        } else if (node.type == NODE_COMMENT) {
            printf(strcat(getTabsRepeated(depth), "comment node (#%d). contents: '%s'\n"), i, node.text_content);
            //printf(strcat(getTabsRepeated(depth), "comment node (#%d). contents: '...'\n"), i);
        } else if (node.type == NODE_ELEMENT) {
            printf(strcat(getTabsRepeated(depth), "element node (#%d). node (simplified): <%s>...</%s>\n"), i, node.name, node.name);
            if (node.children.count) {
                recursiveDisplayXML(node.children, depth + 1);
            }
            printf(strcat(getTabsRepeated(depth), "element node: end (%s)\n"), node.name);
        }
    }
}*/

int main(int argc, char **argv) {
    if (argc == 1) {
        printf("%s [URL]\n", argv[0]);
        exit(0);
    }
    char *url = argv[1];

    struct http_response parsedResponse = http_makeHTTPRequest(url);
    
    if (parsedResponse.error) {
        if (parsedResponse.error == 4) {
            printf("Please enter a valid URL.\n");
        } else if (parsedResponse.error < 4) {
            printf("HTTP error while making request.\n");
        } else if (parsedResponse.error != 5) {
            printf("Encountered error while making HTTP request. Error code: %d\n", parsedResponse.error);
        }
        return 1;
    }
    
    
    printf("response details:\n");
    printf("    code: %d\n", parsedResponse.response_code);
    printf("    desc: %s\n", parsedResponse.response_description);
    printf("    chunked: %d\n", parsedResponse.is_chunked);
    printf("    content length: %d\n", parsedResponse.content_length);
    for (int i = 0; i < parsedResponse.num_headers; i ++) {
        printf("    header name: %s; header value: %s\n", parsedResponse.headers[i].name, parsedResponse.headers[i].value);
    }
    /*
    char *xmlfortest = (
"<p>I'm not actually saying your site should look like this. What I'm saying is that all the problems we have with websites are <strong>ones we create ourselves</strong>. Websites aren't broken by default, they are functional, high-performing, and accessible. You break them.</p>\n\
        \n\
        <blockquote cite=\"https://www.vitsoe.com/us/about/good-design\">\"Good design is as little design as possible.\"<br>\n\
            - some German guy\n\
        </blockquote>\n\
    \n\
    <hr>");*/
    
    printf("    body: %s\n", parsedResponse.response_body.data);
    
    struct xml_response xml = XML_parseXmlNodes(
                                  XML_xmlDataFromString(
                                      parsedResponse.response_body.data
                                  )
                              );
    if (xml.error) {
        printf("Error while parsing xml. error code: %d\n", xml.error);
        exit(1);
    }
    
    
    struct nc_state browserState;
    browserState.currentPage = PAGE_EMPTY;
    browserState.currentLoadedDOM = xml;
    browserState.numTextAreas = 0;
    browserState.numButtons = 0;
    browserState.numTexts = 0;
    browserState.selectables = (struct nc_selected *) calloc(0, sizeof(struct nc_selected));
    browserState.numSelectables = 0;
    browserState.selectableIndex = 0;
    initBrowserWindow(&browserState);
    eventLoop(&browserState);
    
    return 0;
}
